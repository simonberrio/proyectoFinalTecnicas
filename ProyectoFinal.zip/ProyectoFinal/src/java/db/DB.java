/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author mateo.llano
 */
public class DB {

    private static Connection connection;
    private String USERNAME = "root";
    private String PASSWORD = "";
    private String HOST = "localhost";
    private String PORT = "3306";
    private String DATABASE = "simonSemillerios";
    private String CLASSNAME = "com.mysql.jdbc.Driver";
    private String URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE + "?zeroDateTimeBehavior=convertToNull";

    private DB() {
    }

    public Connection getConexion() {
        try {
            Class.forName(CLASSNAME);
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Conexión Exitosa");
        }
        catch (SQLException | ClassNotFoundException e) {
            System.out.println("Error en getConexion() " + e);
            e.printStackTrace();
        }
        return connection;
    }
}
